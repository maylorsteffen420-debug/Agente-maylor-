# MAYLOR AI + Gemini 2.5 Flash

## 1. Configure a API
- Crie uma chave no Google AI Studio.
- Configure `GEMINI_API_KEY` como variável de ambiente/secret no serviço que hospedará o backend.
- Configure `ALLOWED_ORIGINS` com o domínio exato do frontend.
- Nunca coloque a chave Gemini no HTML, JavaScript do navegador ou repositório público.

## 2. Instale e execute localmente
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
# Defina GEMINI_API_KEY e ALLOWED_ORIGINS no ambiente
uvicorn main:app --host 0.0.0.0 --port 8000
```

Teste: `GET http://localhost:8000/api/health`

## 3. Conecte o frontend
Abra `index.html`, vá em **Configurar IA** e informe a URL pública do backend (ex.: `https://seu-backend.example.com`). Se frontend e backend estiverem no mesmo domínio, deixe o campo vazio.

## Observações importantes
- Este pacote integra respostas de texto e contexto recente da conversa via Gemini 2.5 Flash.
- Voz é capturada/lida pelo navegador; a resposta inteligente é gerada no backend.
- A pesquisa e a geração de imagens continuam como recursos separados e ainda precisam de integrações próprias.
- Antes de liberar acesso público, adicione autenticação por usuário, limites de requisições, proteção contra abuso e política de privacidade. CORS não é autenticação.
